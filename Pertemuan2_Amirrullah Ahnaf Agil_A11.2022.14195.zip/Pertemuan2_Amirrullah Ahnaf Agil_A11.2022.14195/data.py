import csv

# Membaca data dari file CSV
def baca_csv(nama_file):
    data = []
    with open(nama_file, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)
    return data

# Penskalaan fitur
def penskalaan_fitur(data):
    for i in range(len(data)):
        for j in range(len(data[i])):
            data[i][j] = float(data[i][j])
    return data

# Menampilkan beberapa baris data setelah preprocessing
def tampilkan_data(data):
    for i in range(min(5, len(data))):
        print("Baris {}: {}".format(i+1, data[i]))

# Main program
def main():
    # Baca data dari file CSV
    nama_file = 'data.csv'
    data = baca_csv(nama_file)

    # Penskalaan fitur
    data_scaled = penskalaan_fitur(data)

    # Tampilkan data setelah preprocessing
    print("Data setelah preprocessing:")
    tampilkan_data(data_scaled)

if __name__ == "__main__":
    main()
